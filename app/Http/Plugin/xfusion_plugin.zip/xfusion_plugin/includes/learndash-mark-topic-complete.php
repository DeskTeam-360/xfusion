<?php
/**
 * Shortcode [mark_complete_button topic_id=""] + AJAX mark topic complete.
 *
 * @package XFusion
 */

defined('ABSPATH') || exit;

function xfusion_custom_mark_complete_button($atts): string
{
    $atts = shortcode_atts([
        'topic_id' => '',
    ], $atts, 'mark_complete_button');

    if (empty($atts['topic_id'])) {
        return '';
    }

    $topic_id = (int) $atts['topic_id'];

    return sprintf(
        '<button type="button" class="mark-as-complete" data-topic-id="%s">Mark as Complete</button>',
        esc_attr((string) $topic_id)
    );
}

add_shortcode('mark_complete_button', 'xfusion_custom_mark_complete_button');

add_action('wp_ajax_mark_topic_complete', 'xfusion_mark_topic_complete');
add_action('wp_ajax_nopriv_mark_topic_complete', 'xfusion_mark_topic_complete');

function xfusion_mark_topic_complete(): void
{
    check_ajax_referer('xfusion_mark_topic_complete', 'nonce');

    if (!isset($_POST['topic_id'], $_POST['user_id'])) {
        wp_send_json_error('Invalid request');
        return;
    }

    $user_id = (int) $_POST['user_id'];
    $topic_id = (int) $_POST['topic_id'];

    if (!function_exists('learndash_is_topic_complete') || !function_exists('learndash_process_mark_complete')) {
        wp_send_json_error('LearnDash not available');
        return;
    }

    if (learndash_is_topic_complete($user_id, $topic_id)) {
        wp_send_json_success('Topic already completed');
        return;
    }

    if (learndash_process_mark_complete($user_id, $topic_id)) {
        wp_send_json_success();
    } else {
        wp_send_json_error('Failed to mark topic as complete');
    }
}

add_action('wp_enqueue_scripts', 'xfusion_enqueue_mark_topic_complete_scripts');

function xfusion_enqueue_mark_topic_complete_scripts(): void
{
    wp_register_script(
        'xfusion-mark-topic-complete',
        false,
        ['jquery'],
        null,
        true
    );
    wp_enqueue_script('xfusion-mark-topic-complete');

    wp_localize_script('xfusion-mark-topic-complete', 'xfusionMarkTopic', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'user_id'  => get_current_user_id(),
        'nonce'    => wp_create_nonce('xfusion_mark_topic_complete'),
    ]);

    $inline = <<<'JS'
(function ($) {
    $(function () {
        $(document).on('click', '.mark-as-complete', function () {
            var topicId = $(this).data('topic-id');
            $.ajax({
                url: xfusionMarkTopic.ajax_url,
                type: 'POST',
                data: {
                    action: 'mark_topic_complete',
                    topic_id: topicId,
                    user_id: xfusionMarkTopic.user_id,
                    nonce: xfusionMarkTopic.nonce
                },
                success: function (response) {
                    if (!response.success) {
                        alert(typeof response.data === 'string' ? response.data : (response.data && response.data.message) || 'Error');
                    }
                }
            });
        });
    });
})(jQuery);
JS;

    wp_add_inline_script('xfusion-mark-topic-complete', $inline, 'after');
}
